# Transfer-learning-based-classification-of-poultry-diseases-for-enhanced-health-management
poultry disease detection
